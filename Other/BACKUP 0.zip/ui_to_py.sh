#!/bin/bash
python3 "ui to py.py"
echo "end"
read NONE
exit 0
